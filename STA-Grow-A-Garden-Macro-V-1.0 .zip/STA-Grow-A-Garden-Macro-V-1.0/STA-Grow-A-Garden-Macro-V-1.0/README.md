# STAs-Grow-A-Garden-Macro

HOW TO USE:

F5 to stat

F7 to stop